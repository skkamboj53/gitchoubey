<?php
/*

    Custom Post Type Class
    used to help create custom post types for Wordpress
    http://github.com/jjgrainger/wp-custom-post-type-class/

    @author     jjgrainger
    @url        http://jjgrainger.co.uk

*/
class CPT {

    /*
        @var  string  $post_type_name
        Public variable that holds the name of the post type
        assigned on __contstruct()
    */

    public $post_type_name;



    /*
        @var  string  $singular
        Public variable that holds the singular name of the post type
        This is a human friendly name, capitalized with spaces
        assigned on __contstruct()
    */

    public $singular;



    /*
        @var  string  $singular
        Public variable that holds the plural name of the post type
        This is a human friendly name, capitalized with spaces
        assigned on __contstruct()
    */

    public $plural;



    /*
        @var  string  $slug
        Public variable that holds the slug name of the post type
        This is a robot friendly name, all lowercase and uses hyphens
        assigned on __contstruct()
    */

    public $slug;



    /*
        @var  array  $options
        public variable that holds the user submited options of the post type
        assigined on __construct()
    */

    public $options;



    /*
        @var  array  $taxonomies
        public variable that holds an array of the taxonomies associated with the post type
        assigined on register_taxonomy()
    */

    public $taxonomies;



    /*
        @var  array  $filters
        use to define which filters are to appear on admin edit screen
        used in add_taxonmy_filters()
    */

    public $filters; 



    /*
        @var  array  $columns
        use to define which columns are to appear on admin edit screen
        used in add_admin_columns()
    */

    public $columns;



    /*
        @var  array  $custom_populate_columns
        an array of user defined functions to populate admin columns
    */

    public $custom_populate_columns;



    /*
        @var  array  $sortable
        use to define which columns are to sortable on admin edit screen
    */

    public $sortable;



    /*
        @function __contructor(@post_type_name, @options)
        
        @param  mixed   $post_type_names    The name(s) of the post type, accepts (post type name, slug, plural, singlualr)
        @param  array   $options            User submitted options
    */

    function __construct($post_type_names, $options = array()) {

        // check if post type names is string or array
        if(is_array($post_type_names)) {
            
            // add names to object
            $names = array(
                'singular',
                'plural',
                'slug'
            );

            // set the post type name
            $this->post_type_name = $post_type_names['post_type_name'];

            // cycle through possible names
            foreach($names as $name) {

                // if the name has been set by user
                if(isset($post_type_names[$name])) {

                    // use the user setting
                    $this->$name = $post_type_names[$name];
                
                // else generate the name
                } else {

                    // define the method to be used
                    $method = 'get_'.$name;

                    // generate the name
                    $this->$name = $this->$method();
                
                }
            
            }

        // else the post type name is only supplied
        } else {

            // apply to post type name
            $this->post_type_name = $post_type_names;

            // set the slug name
            $this->slug = $this->get_slug();

            // set the plural name label
            $this->plural = $this->get_plural();

            // set the singular name label
            $this->singular = $this->get_singular();

        }

        // set the user submitted options to the object
        $this->options = $options;      

        // register the post type
        $this->add_action('init', array(&$this, 'register_post_type'));

        // add taxonomy to admin edit columns
        $this->add_filter('manage_edit-' . $this->post_type_name . '_columns', array(&$this, 'add_admin_columns'));

        // populate the taxonomy columns with the posts terms
        $this->add_action('manage_' . $this->post_type_name . '_posts_custom_column', array(&$this, 'populate_admin_columns'), 10, 2);
    }



    /*
        helper function get
        used to get an object variable

        @param  string  $var        the variable you would like to retrieve
        @return mixed               returns the value on sucess, bool (false) when fails

    */

    function get($var) {

        // if the variable exisits
        if($this->$var) {

            // on success return the value
            return $this->$var;

        } else {

            // on fail return false
            return false;

        }
    }



    /*
        helper function set
        used to set an object variable
        can overwrite exisiting variables and create new ones
        cannot overwrite reserved variables

        @param  mixed  $var         the variable you would like to create/overwrite
        @param  mixed  $value       the value you would like to set to the variable

    */

    function set($var, $value) {

        // an array of reserved variables that cannot be overwritten
        $reserved = array(
            'config',
            'post_type_name',
            'singular',
            'plural',
            'slug',
            'options',
            'taxonomies'
        );

        // if the variable is not a reserved variable
        if(!in_array($var, $reserved)) {

            // write variable and value
            $this->$var = $value;
        
        }

    }


    /*
        helper function options_merge
        merges user submitted options array with default settings
        preserving default data if not included in user options

        @param  array  $defaults        the default option array
        @param  array  $options         user submitted options to add/override defaults

    */

    function options_merge($defaults, $options) {
        
        // set the new array as defaults
        $new_array = $defaults;

        // foreach new option to be added
        foreach($options as $key => $value) {
            
            // if isset in the defaults array
            if(isset($defaults[$key])) {

                // if this option is a nested array
                if(is_array($defaults[$key])) {

                    // repeat the process
                    $new_array[$key] = $this->options_merge($defaults[$key], $options[$key]);

                // else if the value is not an array
                } else {

                    // overide with user submitted option
                    $new_array[$key] = $options[$key];

                }

            // else if the default has not been set
            } else {

                // add it to the option
                $new_array[$key] = $value;

            }

        }

        // return the new array
        return $new_array;

    }



    /*
        helper function add_action
        used to create add_action wordpress filter
        
        see Wordpress Codex
        http://codex.wordpress.org/Function_Reference/add_action

        @param  string  $action            name of the action to hook to, e.g 'init'
        @param  string  $function          function to hook that will run on @action
        @param  int     $priority          order in which to execute the function, relation to other function hooked to this action
        @param  int     $accepted_args     the number of arguements the function accepts
    */

    function add_action($action, $function, $priority = 10, $accepted_args = 1) {

        // pass variables into Wordpress add_action function
        add_action($action, $function, $priority, $accepted_args);

    }



    /*
        helper function add_filter
        used to create add_filter wordpress filter
        
        see Wordpress Codex
        http://codex.wordpress.org/Function_Reference/add_filter

        @param  string  $action           name of the action to hook to, e.g 'init'
        @param  string  $function         function to hook that will run on @action
        @param  int     $priority         order in which to execute the function, relation to other function hooked to this action
        @param  int     $accepted_args    the number of arguements the function accepts
    */

    function add_filter($action, $function, $priority = 10, $accepted_args = 1) {

        // pass variables into Wordpress add_action function
        add_filter($action, $function, $priority, $accepted_args);

    }



    /*
        helper function get slug
        creates url friendly slug

        @param  string  $name           name to slugify
        @return string  $name           returns the slug
    */

    function get_slug($name = null) {

        // if no name set use the post type name
        if(!isset($name)) {

            $name = $this->post_type_name;

        }

        // name to lower case
        $name = strtolower($name);

        // replace spaces with hyphen
        $name = str_replace(" ", "-", $name);

        // replace underscore with hyphen
        $name = str_replace("_", "-", $name);

        return $name;

    }



    /*
        helper function get_plural
        returns the friendly plural name

        ucwords      capitalize words
        strtolower   makes string lowercase before capitalizing
        str_replace  replace all instances of _ to space
        
        @param   string  $name      the slug name you want to pluralize
        @return  string             the friendly pluralized name
    */

    function get_plural($name = null) {

        // if no name is passed the post_type_name is used
