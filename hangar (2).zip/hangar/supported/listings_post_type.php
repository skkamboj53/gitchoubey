<?php 
/**
 * Create listings post type
 */
$listings = new CPT(
    'listing', array(
        'supports' => array('title', 'editor', 'thumbnail', 'comments', 'author','custom-fields'),
        'menu_icon' => get_template_directory_uri() . '/images/listings_icon.png',
));

/**
 * Taxonomy for listings
 */
$listings->register_taxonomy(array(
    'taxonomy_name' => 'listings_categories',
    'singular' => 'Listing Category',
    'plural' => 'Listing Categories',
    'slug' => 'listings'
    
));
$listings->register_taxonomy(array(
    'taxonomy_name' => 'listings_location',
    'singular' => 'Listing Location',
    'plural' => 'Listing Locations',
    'slug' => 'location'
));
// define the columns to appear on the admin edit screen
$listings->columns(array(
    'cb' => '<input type="checkbox" />',
    'title' => __('Listing Title'),
    'listings_categories' => __('Listing Categories','atlas'),
    'listings_location' => __('Listing Locations','atlas'),
    'rating' => __('Listing Rating','atlas'),
    'date' => __('Date','framework'),
    'author' => __('Author','framework'),
    'expire_date' => __('Expire Date','framework'),
));
// populate the ratings column
$listings->populate_column('rating', function($column, $post) { ?>

    <?php if(get_field('enable_ratings_system','option')) { ?>
                    <?php 
                    $overall_rating = tdp_get_rating(); 
                    ?>
                        <ul class="admin-rating">
                            <?php if($overall_rating == '1') { ?>
                                <li><span class="icon-star"></span></li>
                            <?php } else if($overall_rating == '2') { ?>
                                <li><span class="icon-star"></span></li>
                                <li><span class="icon-star"></span></li>
                            <?php } else if($overall_rating == '3') { ?>
                                <li><span class="icon-star"></span></li>
                                <li><span class="icon-star"></span></li>
                                <li><span class="icon-star"></span></li>
                            <?php } else if($overall_rating == '4') { ?>
                                <li><span class="icon-star"></span></li>
                                <li><span class="icon-star"></span></li>
                                <li><span class="icon-star"></span></li>
                                <li><span class="icon-star"></span></li>
                            <?php } else if($overall_rating == '5') { ?>
                                <li><span class="icon-star"></span></li>
                                <li><span class="icon-star"></span></li>
                                <li><span class="icon-star"></span></li>
                                <li><span class="icon-star"></span></li>
                                <li><span class="icon-star"></span></li>
                            <?php } ?>
                        </ul>
                <?php } 
});

// populate the ratings column
$listings->populate_column('expire_date', function($column, $post) { 

    if ( $post->_listing_expires )
                    echo '<strong>' . date_i18n( __( 'M j, Y', 'wp-job-manager' ), strtotime( $post->_listing_expires ) ) . '</strong>';
                else
                    echo '&ndash;';

});

// make rating and price columns sortable
$listings->sortable(array(
    'price' => array('price', true),
    'rating' => array('rating', true)
));

if ( ! function_exists( 'tdp_listings_tags' ) ) {

// Register Custom Taxonomy
function tdp_listings_tags() {

    $labels = array(
        'name'                       => _x( 'Listings Tags', 'Taxonomy General Name', 'hangar' ),
        'singular_name'              => _x( 'Listing Tag', 'Taxonomy Singular Name', 'hangar' ),
        'menu_name'                  => __( 'Listing Tag', 'hangar' ),
        'all_items'                  => __( 'All Items', 'hangar' ),
        'parent_item'                => __( 'Parent Item', 'hangar' ),
        'parent_item_colon'          => __( 'Parent Item:', 'hangar' ),
        'new_item_name'              => __( 'New Item Name', 'hangar' ),
        'add_new_item'               => __( 'Add New Item', 'hangar' ),
        'edit_item'                  => __( 'Edit Item', 'hangar' ),
        'update_item'                => __( 'Update Item', 'hangar' ),
        'separate_items_with_commas' => __( 'Separate items with commas', 'hangar' ),
        'search_items'               => __( 'Search Items', 'hangar' ),
        'add_or_remove_items'        => __( 'Add or remove items', 'hangar' ),
        'choose_from_most_used'      => __( 'Choose from the most used items', 'hangar' ),
        'not_found'                  => __( 'Not Found', 'hangar' ),
    );
    $rewrite = array(
        'slug'                       => 'listings-tags',
        'with_front'                 => true,
        'hierarchical'               => true,
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => false,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => false,
        'rewrite'                    => $rewrite,
    );
    register_taxonomy( 'listings_tags', 'listing', $args );

}

// Hook into the 'init' action
add_action( 'init', 'tdp_listings_tags', 0 );

}