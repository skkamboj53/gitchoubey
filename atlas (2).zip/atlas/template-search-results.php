<?php
/*
Template Name: Search Results Page
*/
get_header();

$page_sidebar = get_field('inner_page_layout');

$search_query = isset($_GET['search_query']) ? sanitize_text_field($_GET['search_query']) : '';
$post_type = 'listing';

// Prepare the WP_Query arguments
$args = [
    'post_type' => $post_type,
    's' => $search_query, // Use the search query
    'posts_per_page' => -1 // Adjust this as needed
];

// Add taxonomy queries if they exist
$tax_query = [];

    if (!empty($_GET['main_cat']) && $_GET['main_cat'] != -1) {
        $tax_query[] = [
            'taxonomy' => 'listings_categories',
            'field' => 'term_id',
            'terms' => sanitize_text_field($_GET['main_cat']),
        ];
    }
    if (!empty($_GET['main_loc']) && $_GET['main_loc'] != -1) {
        $tax_query[] = [
            'taxonomy' => 'listings_location',
            'field' => 'term_id',
            'terms' => sanitize_text_field($_GET['main_loc']),
        ];
    }

    if (!empty($_GET['tax_listings_tags']) && is_array($_GET['tax_listings_tags'])) {
        $tag_ids = array_map('sanitize_text_field', $_GET['tax_listings_tags']); // Sanitize the array of tags
        $tax_query[] = [
            'taxonomy' => 'listings_tags', // Custom taxonomy for tags (change to your actual taxonomy slug)
            'field' => 'slug', // Using term_id for filtering by IDs
            'terms' => $tag_ids, // Array of term IDs for tags
            'operator' => 'IN', // Matches any of the provided terms
        ];
    }


// Add tax query to args if any
if (!empty($tax_query)) {
    $tax_query['relation'] = 'AND';
    $args['tax_query'] = $tax_query;
}

$meta_query = [];

// Handle wheelchair accessibility
if (!empty($_GET['wheelchair']) && $_GET['wheelchair'] != -1) {
    $meta_query[] = [
        'key' => 'acf_disabled', // Assuming 'wheelchair_accessible' is the meta key
        'value' => $_GET['wheelchair'], // Filter for listings that are wheelchair accessible
        'compare' => '=', // Exact match
    ];
}

// Handle zip code filtering
if (!empty($_GET['zipcode'])) {
    $meta_query[] = [
        'key' => 'location', // Assuming 'zipcode' is the meta key
        'value' => sanitize_text_field($_GET['zipcode']), // Sanitize zip code input
        'compare' => 'LIKE', // Perform a partial match (you could use '=' for an exact match)
    ];
}

// Add meta_query filters if any
if (!empty($meta_query)) {
    $meta_query['relation'] = 'AND'; // Combine meta queries with 'AND'
    $args['meta_query'] = $meta_query;
}

// Execute the custom query
$wp_query = new WP_Query($args);


?>

<section id="header-map" class="slidingDiv <?php echo (!$wp_query->have_posts()) ? 'nothing-found' : ''; ?>">
    <a href="#search-popup" id="open-search"><span class="icon-search"></span></a>
    <div id="map"></div>
</section>

<script type="text/javascript">
    jQuery(document).ready(function($) {
        var mapDiv = $("#map");
        var mapOptions = {
            zoom: <?php echo get_field('adjust_zoom', 'option') ?: '18'; ?>,
            draggable: <?php echo get_field('is_draggable', 'option') ? "true" : 'false'; ?>,
            mapTypeId: google.maps.MapTypeId.<?php echo esc_js(get_field('map_type_id', 'option')); ?>,
            center: new google.maps.LatLng(0, 0), // Placeholder center
            scrollwheel: false,
            panControl: true,
            scaleControl: true,
            streetViewControl: <?php echo get_field('street_view_control', 'option') ? "true" : 'false'; ?>,
            zoomControl: <?php echo get_field('zoom_control', 'option') ? "true" : 'false'; ?>
        };

        var map = new google.maps.Map(mapDiv[0], mapOptions);
        var markers = [];

        <?php if ($wp_query->have_posts()) : ?>
            <?php while ($wp_query->have_posts()) : $wp_query->the_post(); ?>
                <?php 
                $address = get_field('location');
                if (!empty($address['coordinates'])) :
                    $coordinates = explode(',', $address['coordinates']);
                ?>
                    var marker = new google.maps.Marker({
                        position: new google.maps.LatLng(<?php echo esc_js(trim($coordinates[0])); ?>, <?php echo esc_js(trim($coordinates[1])); ?>),
                        map: map,
                        title: '<?php echo esc_js(get_the_title()); ?>'
                    });
                    markers.push(marker);
                <?php endif; ?>
            <?php endwhile; ?>
        <?php endif; ?>

        // Optional: Adjust map center to the first marker or a specific location
        if (markers.length > 0) {
            map.setCenter(markers[0].getPosition());
        }
    });
</script>

<?php if (get_field('display_breadcrumb', 'option')) : ?>
    <section id="breadcrumb">
        <div class="wrapper">
            <div class="one_half">
                <div id="crumbs" xmlns:v="http://rdf.data-vocabulary.org/#">
                    <span class="icon-location"></span>
                    <span typeof="v:Breadcrumb">
                        <a rel="v:url" property="v:title" href="<?php echo home_url(); ?>"><?php _e('Home', 'atlas'); ?></a>
                    </span> » 
                    <span class="current"><?php _e('Search Results', 'atlas') ?></span>
                </div>
            </div>
            <div class="one_half last"></div>
            <div class="clearboth"></div>
        </div>
    </section>
<?php endif; ?>

<section id="listing-brief">
    <div class="wrapper">
        <div class="two_third">
            <div class="animated fadeInDown">
                <h1>
                    <?php
                    echo __('Displaying results ', 'atlas') . $wp_query->found_posts;
                    if ($search_query) {
                        echo __(' For: ', 'atlas') . esc_html($search_query);
                    }
                    ?>
                </h1>
            </div>
        </div>
        <div class="one_third last" id="right-counter"></div>
        <div class="clearboth"></div>
    </div>
</section>

<section id="page-wrapper">
    <div id="page-content" class="wrapper">
        <?php if ($wp_query->have_posts()) : ?>
            <div id="content-container">
                <?php 
                while ($wp_query->have_posts()) : $wp_query->the_post(); ?>
                    <div class="grid-column one_third">
                        <?php get_template_part('content', 'single-result-grid'); ?>
                    </div>
                <?php endwhile; ?>
                <div class="clear"></div>
            </div>
        <?php else : ?>
            <div class="error-container">
                <h1 class="entry-title">
                    <span class="error-title"><i class="icon-attention-circled"></i></span>
                    <?php _e('Oops! It looks like nothing was found.', 'atlas'); ?>
                </h1>
                <p><?php _e('You might want to try with different search terms.', 'atlas'); ?></p>
                <a href="<?php echo home_url(); ?>" class="dp-button large"><?php _e('Back To The Homepage', 'atlas'); ?></a>
            </div>
        <?php endif; ?>

        <?php wp_reset_postdata(); // Reset the global post object ?>
    </div>
</section>

<?php get_footer(); ?>
