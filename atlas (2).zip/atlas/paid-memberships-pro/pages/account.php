<?php
	global $wpdb, $pmpro_msg, $pmpro_msgt, $pmpro_levels, $current_user, $levels, $pmpro_currency_symbol;
	
	//if a member is logged in, show them some info here (1. past invoices. 2. billing information with button to update.)
	if($current_user->membership_level->ID)
	{
	?>	
	<div class="tdp-wrap tdp-login ">
		
		<div class="tdp-inner tdp-login-wrapper">

			<div class="tdp-head">

				<div class="tdp-left">

					<div class="tdp-field-name tdp-field-name-wide login-heading" id="login-heading-1">
						<?php _e("Your membership is <strong>active</strong>.", 'atlas');?>
					</div>

				</div>

				<div class="tdp-right">
					<?php _e("Membership", 'atlas');?>: <?php echo $current_user->membership_level->name?>
				</div>

				<div class="tdp_clear"></div>

			</div>

			<div class="tdp-main">

				<ul>
				<?php if($current_user->membership_level->billing_amount > 0) { ?>
					<li><strong><?php _e("Membership Fee", 'atlas');?>:</strong>
					<?php
						$level = $current_user->membership_level;
						if($current_user->membership_level->cycle_number > 1) {
							printf(__('%s every %d %s.', 'atlas'), $pmpro_currency_symbol . $level->billing_amount, $level->cycle_number, pmpro_translate_billing_period($level->cycle_period, $level->cycle_number));
						} elseif($current_user->membership_level->cycle_number == 1) {
							printf(__('%s per %s.', 'atlas'), $pmpro_currency_symbol . $level->billing_amount, pmpro_translate_billing_period($level->cycle_period));
						} else { 
							echo $pmpro_currency_symbol, $current_user->membership_level->billing_amount;
						}
					?>
					</li>
				<?php } ?>						
				
				<?php if($current_user->membership_level->billing_limit) { ?>
					<li><strong><?php _e("Duration", 'atlas');?>:</strong> <?php echo $current_user->membership_level->billing_limit.' '.sornot($current_user->membership_level->cycle_period,$current_user->membership_level->billing_limit)?></li>
				<?php } ?>
				
				<?php if($current_user->membership_level->enddate) { ?>
					<li><strong><?php _e("Membership Expires", 'atlas');?>:</strong> <?php echo date_i18n(get_option('date_format'), $current_user->membership_level->enddate)?></li>
				<?php } ?>
				
				<?php if($current_user->membership_level->trial_limit == 1) 
				{ 
					printf(__("Your first payment will cost %s.", 'atlas'), $pmpro_currency_symbol . $current_user->membership_level->trial_amount);
				}
				elseif(!empty($current_user->membership_level->trial_limit)) 
				{
					printf(__("Your first %d payments will cost %s.", 'atlas'), $current_user->membership_level->trial_limit, $pmpro_currency_symbol . $current_user->membership_level->trial_amount);
				}
				?>
				</ul>

				<div class="tdp_clear"></div>

				<div class="tdp-field tdp-seperator tdp-edit tdp-edit-show"><?php _e("My Account", 'atlas');?></div>

				<div id="tdp_account-profile" class="tdp_box">	
					 <?php get_currentuserinfo(); ?> 
						<?php if($current_user->user_firstname) { ?>
							<p><?php echo $current_user->user_firstname?> <?php echo $current_user->user_lastname?></p>
						<?php } ?>
						<ul>
							<li><strong><?php _e("Username", 'atlas');?>:</strong> <?php echo $current_user->user_login?></li>
							<li><strong><?php _e("Email", 'atlas');?>:</strong> <?php echo $current_user->user_email?></li>
						</ul>
						<p>
							<a href="<?php the_field('edit_profile_page','option');?>"><?php _e('Edit Profile', 'atlas');?></a> |
							<a href="<?php the_field('edit_profile_page','option');?>"><?php _e('Change Password', 'atlas');?></a>
						</p>
				</div> <!-- end tdp_account-profile -->


				
				<div class="tdp-field tdp-seperator tdp-edit tdp-edit-show"><?php _e("Membership Allowance", 'atlas');?></div>

				<?php printf(__("Original Membership Allowance <strong class='tdp-allowance-number'>%s</strong>.", 'atlas'), pmpro_get_membership_allowance($current_user->membership_level->ID)); ?>

				<p><?php printf(__("Your current listings allowance is of <strong class='tdp-allowance-number'>%s</strong>.",'atlas'), $current_user->pmpro_allowance_limit ); ?></p>

				<ul>
					<li><a href="<?php echo get_field('listings_management_page','option');?>"><?php _e('Manage your listings','atlas');?></a></li>
						<li><a href="<?php echo get_field('submit_new_listing_page','option');?>"><?php _e('Publish New listing','atlas');?></a></li>

				</ul>

				<br>

				<?php
				//last invoice for current info
				//$ssorder = $wpdb->get_row("SELECT *, UNIX_TIMESTAMP(timestamp) as timestamp FROM $wpdb->pmpro_membership_orders WHERE user_id = '$current_user->ID' AND membership_id = '" . $current_user->membership_level->ID . "' AND status = 'success' ORDER BY timestamp DESC LIMIT 1");				
				$ssorder = new MemberOrder();
				$ssorder->getLastMemberOrder();
				$invoices = $wpdb->get_results("SELECT *, UNIX_TIMESTAMP(timestamp) as timestamp FROM $wpdb->pmpro_membership_orders WHERE user_id = '$current_user->ID' ORDER BY timestamp DESC LIMIT 6");				
				if(!empty($ssorder->id) && $ssorder->gateway != "check" && $ssorder->gateway != "paypalexpress" && $ssorder->gateway != "paypalstandard" && $ssorder->gateway != "twocheckout")
				{
					//default values from DB (should be last order or last update)
					$bfirstname = get_user_meta($current_user->ID, "pmpro_bfirstname", true);
					$blastname = get_user_meta($current_user->ID, "pmpro_blastname", true);
					$baddress1 = get_user_meta($current_user->ID, "pmpro_baddress1", true);
					$baddress2 = get_user_meta($current_user->ID, "pmpro_baddress2", true);
					$bcity = get_user_meta($current_user->ID, "pmpro_bcity", true);
					$bstate = get_user_meta($current_user->ID, "pmpro_bstate", true);
					$bzipcode = get_user_meta($current_user->ID, "pmpro_bzipcode", true);
					$bcountry = get_user_meta($current_user->ID, "pmpro_bcountry", true);
					$bphone = get_user_meta($current_user->ID, "pmpro_bphone", true);
					$bemail = get_user_meta($current_user->ID, "pmpro_bemail", true);
					$bconfirmemail = get_user_meta($current_user->ID, "pmpro_bconfirmemail", true);
					$CardType = get_user_meta($current_user->ID, "pmpro_CardType", true);
					$AccountNumber = hideCardNumber(get_user_meta($current_user->ID, "pmpro_AccountNumber", true), false);
					$ExpirationMonth = get_user_meta($current_user->ID, "pmpro_ExpirationMonth", true);
					$ExpirationYear = get_user_meta($current_user->ID, "pmpro_ExpirationYear", true);	
					?>	
					
					<div id="pmpro_account-billing" class="pmpro_box">
						<h3><?php _e("Billing Information", 'atlas');?></h3>
						<?php if(!empty($baddress1)) { ?>
						<p>
							<strong><?php _e("Billing Address", 'atlas');?></strong><br />
							<?php echo $bfirstname . " " . $blastname?>
							<br />		
							<?php echo $baddress1?><br />
							<?php if($baddress2) echo $baddress2 . "<br />";?>
							<?php if($bcity && $bstate) { ?>
								<?php echo $bcity?>, <?php echo $bstate?> <?php echo $bzipcode?> <?php echo $bcountry?>
							<?php } ?>                         
							<br />
							<?php echo formatPhone($bphone)?>
						</p>
						<?php } ?>
						
						<?php if(!empty($AccountNumber)) { ?>
						<p>
							<strong><?php _e("Payment Method", 'atlas');?></strong><br />
							<?php echo $CardType?>: <?php echo last4($AccountNumber)?> (<?php echo $ExpirationMonth?>/<?php echo $ExpirationYear?>)
						</p>
						<?php } ?>
						
						<?php 
							if((isset($ssorder->status) && $ssorder->status == "success") && (isset($ssorder->gateway) && in_array($ssorder->gateway, array("authorizenet", "paypal", "stripe", "braintree", "payflow", "cybersource")))) 
							{ 
								?>
								<p><a href="<?php echo pmpro_url("billing", "")?>"><?php _e("Edit Billing Information", 'atlas'); ?></a></p>
								<?php 
							} 
						?>
					</div> <!-- end pmpro_account-billing -->				
				<?php
				}
			?>
			
			<?php if(!empty($invoices)) { ?>
			<div id="pmpro_account-invoices" class="pmpro_box">
				<h3><?php _e("Past Invoices", 'atlas');?></h3>
				<ul>
					<?php 
						$count = 0;
						foreach($invoices as $invoice)
						{ 
							if($count++ > 5)
								break;
							?>
							<li><a href="<?php echo pmpro_url("invoice", "?invoice=" . $invoice->code)?>"><?php echo date_i18n(get_option("date_format"), $invoice->timestamp)?> (<?php echo $pmpro_currency_symbol?><?php echo $invoice->total?>)</a></li>
							<?php
						}
					?>
				</ul>
				<?php if($count == 6) { ?>
					<p><a href="<?php echo pmpro_url("invoice"); ?>"><?php _e("View All Invoices", 'atlas');?></a></p>
				<?php } ?>
			</div> <!-- end pmpro_account-billing -->
			<?php } ?>
				
			<div id="pmpro_account-links" class="pmpro_box">
						<h3><?php _e("Member Links", 'atlas');?></h3>
						<ul>
							<?php 
								do_action("pmpro_member_links_top");
							?>
							<?php if((isset($ssorder->status) && $ssorder->status == "success") && (isset($ssorder->gateway) && in_array($ssorder->gateway, array("authorizenet", "paypal", "stripe", "braintree", "payflow", "cybersource")))) { ?>
								<li><a href="<?php echo pmpro_url("billing", "", "https")?>"><?php _e("Update Billing Information", 'atlas');?></a></li>
							<?php } ?>
							<?php if(count($pmpro_levels) > 1 && !defined("PMPRO_DEFAULT_LEVEL")) { ?>
								<li><a href="<?php echo pmpro_url("levels")?>"><?php _e("Change Membership Level", 'atlas');?></a></li>
							<?php } ?>
							<li><a href="<?php echo pmpro_url("cancel")?>"><?php _e("Cancel Membership", 'atlas');?></a></li>
							<?php 
								do_action("pmpro_member_links_bottom");
							?>
						</ul>
					</div> <!-- end pmpro_account-links -->	

				<div class="clear"></div>
				<br>
			
			</div>

		</div>
	
	</div>		
	<?php
	}
?>
