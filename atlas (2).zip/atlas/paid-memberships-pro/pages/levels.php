<?php 
global $wpdb, $pmpro_msg, $pmpro_msgt, $pmpro_levels, $current_user, $pmpro_currency_symbol;
if($pmpro_msg)
{
?>
<div class="pmpro_message message<?php echo $pmpro_msgt?>"><?php echo $pmpro_msg?></div>
<?php
}
?>
	
	<?php	
	$count = 0;
	foreach($pmpro_levels as $level)
	{
	  if(isset($current_user->membership_level->ID))
		  $current_level = ($current_user->membership_level->ID == $level->id);
	  else
		  $current_level = false;
	?>

	<div class="package membership-<?php echo $level->id ?> <?php if($current_level == $level) { ?> active-membership<?php } ?>" id="membership-id-<?php echo $level->id ?>">

		<div class="tdp_two_third">
			<h3><?php echo $current_level ? "{$level->name}" : $level->name?></h3>
			<?php if(!empty($level->description))
						echo apply_filters("the_content", stripslashes($level->description));?>
		</div>

		<div class="tdp_one_third tdp_last">

			<span class="price">
				<?php if(pmpro_isLevelFree($level) || $level->initial_payment === "0.00") { ?>
					<?php _e('FREE', 'atlas');?>
				<?php } else { ?>
					<?php echo $pmpro_currency_symbol?><?php echo $level->initial_payment?>
				<?php } ?>
			</span>

			<h6 class="price-text"><?php printf(__('Posts allowance is of <strong>%s</strong> listings.', 'atlas'), pmpro_get_membership_allowance($level->id) );	 ?></h6>

		</div>

		<div class="tdp_clear"></div>

			
		<?php
			
			if($level->billing_amount != '0.00')
			{


				echo '<div class="divider" style="margin-top:15px;"></div>';
				echo '<div class="features">';


				if($level->billing_limit > 1)
				{			
					if($level->cycle_number == '1')
					{
						printf(__('%s per %s for %d more %s.', 'Recurring payment in cost text generation. E.g. $5 every month for 2 more payments.', 'atlas'), $pmpro_currency_symbol . $level->billing_amount, pmpro_translate_billing_period($level->cycle_period), $level->billing_limit, pmpro_translate_billing_period($level->cycle_period, $level->billing_limit));					
					}				
					else
					{ 
						printf(__('%s every %d %s for %d more %s.', 'Recurring payment in cost text generation. E.g., $5 every 2 months for 2 more payments.', 'atlas'), $pmpro_currency_symbol . $level->billing_amount, $level->cycle_number, pmpro_translate_billing_period($level->cycle_period, $level->cycle_number), $level->billing_limit, pmpro_translate_billing_period($level->cycle_period, $level->billing_limit));					
					}
				}
				elseif($level->billing_limit == 1)
				{
					printf(__('%s after %d %s.', 'Recurring payment in cost text generation. E.g. $5 after 2 months.', 'atlas'), $pmpro_currency_symbol . $level->billing_amount, $level->cycle_number, pmpro_translate_billing_period($level->cycle_period, $level->cycle_number));									
				}
				else
				{
					if($level->cycle_number == '1')
					{
						printf(__('%s per %s.', 'Recurring payment in cost text generation. E.g. $5 every month.', 'atlas'), $pmpro_currency_symbol . $level->billing_amount, pmpro_translate_billing_period($level->cycle_period));					
					}				
					else
					{ 
						printf(__('%s every %d %s.', 'Recurring payment in cost text generation. E.g., $5 every 2 months.', 'atlas'), $pmpro_currency_symbol . $level->billing_amount, $level->cycle_number, pmpro_translate_billing_period($level->cycle_period, $level->cycle_number));					
					}			
				}

				echo '</div>';
			}			
		
						  
			$expiration_text = pmpro_getLevelExpiration($level);
			if($expiration_text)
			{
			?>
				<br /><span class="pmpro_level-expiration"><?php echo $expiration_text?></span>
			<?php
			}
		?>

			<?php if(empty($current_user->membership_level->ID)) { ?>
				<a class="sign-up" href="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https")?>"><?php _e('Sign Up Now', 'atlas');?></a>               
			<?php } elseif ( !$current_level ) { ?>                	
				<a class="sign-up" href="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https")?>"><?php _e('Sign Up Now', 'atlas');?></a>       			
			<?php } elseif($current_level) { ?>      
				<a class="sign-up" href="<?php echo pmpro_url("account")?>"><?php _e('This is your current active membership', 'atlas');?></a>
			<?php } ?>          

	</div>

	<?php } ?>