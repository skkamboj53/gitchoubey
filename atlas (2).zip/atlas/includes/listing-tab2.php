<?php

// Listing Tab 2

?>

<div class="tab-lister">



				<i class="icon-clock"></i>



					<?php echo do_shortcode( '[divider title="'.__('Opening Times','atlas').'" style="right-stripes" length="long" alignment="center" contenttype="text" heading="h4" icon="" iconfont="" fontsize="24" fontcolor="" marginbottom="" margintop=""]' ); ?>



					<ul class="item-address opening-time">



						<?php if(get_field('monday')) :?>

						<li><span><?php _e('Monday','atlas'); ?></span> <?php the_field('monday');?></li>

						<?php endif;?>

						<?php if(get_field('tuesday')) :?>

						<li><span><?php _e('Tuesday','atlas'); ?></span> <?php the_field('tuesday');?></li>

						<?php endif;?>

						<?php if(get_field('wednesday')) :?>

						<li><span><?php _e('Wednesday','atlas'); ?></span> <?php the_field('wednesday');?></li>

						<?php endif;?>

						<?php if(get_field('thursday')) :?>

						<li><span><?php _e('Thursday','atlas'); ?></span> <?php the_field('thursday');?></li>

						<?php endif;?>

						<?php if(get_field('friday')) :?>

						<li><span><?php _e('Friday','atlas'); ?></span> <?php the_field('friday');?></li>

						<?php endif;?>

						<?php if(get_field('saturday')) :?>

						<li><span><?php _e('Saturday','atlas'); ?></span> <?php the_field('saturday');?></li>

						<?php endif;?>

						<?php if(get_field('sunday')) :?>

						<li><span><?php _e('Sunday','atlas'); ?></span> <?php the_field('sunday');?></li>

						<?php endif;?>



					</ul>

			



</div>