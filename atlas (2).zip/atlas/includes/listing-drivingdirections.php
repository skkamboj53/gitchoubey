<?php
// Listing Driving Direction 
// Added in update 1.1

$list_loc_drive = get_field('location');

?>

<div class="tab-lister">

				<i class="icon-direction"></i>

					<?php echo do_shortcode( '[divider title="'.__('Get Directions','atlas').'" style="right-stripes" length="long" alignment="center" contenttype="text" heading="h4" icon="" iconfont="" fontsize="24" fontcolor="" marginbottom="" margintop=""]' ); ?>

					<script type="text/javascript">
						function displayMap() {
					          document.getElementById('map_canvas').style.display="block";
					           initialize();
					     }

					    var directionDisplay;
						var directionsService = new google.maps.DirectionsService();
						function initialize() {

						<?php if(get_field('coordinates_override')) { ?>
							var latlng = new google.maps.LatLng(<?php echo get_field('coordinates_override');?>);
						<?php } else { ?>
							var latlng = new google.maps.LatLng(<?php echo $list_loc_drive['coordinates']; ?>);
						<?php } ?>
						  // set direction render options
						  var rendererOptions = { draggable: true };
						  directionsDisplay = new google.maps.DirectionsRenderer(rendererOptions);
						  var myOptions = {
						    zoom: 14,
						    center: latlng,
						    mapTypeId: google.maps.MapTypeId.ROADMAP,
						    mapTypeControl: false
						  };
						  // add the map to the map placeholder
						  var map2 = new google.maps.Map(document.getElementById("map_canvas"),myOptions);
						  directionsDisplay.setMap(map2);
						  directionsDisplay.setPanel(document.getElementById("directionsPanel"));
						  // Add a marker to the map for the end-point of the directions.
						  var marker = new google.maps.Marker({
						    position: latlng, 
						    map: map2, 
						    title:"<?php the_title();?>"
						  }); 
    					 
						}
						function calcRoute() {
						  console.log('submit clicked');
						  const directionsService = new google.maps.DirectionsService();
						  
						  const directionsRenderer = new google.maps.DirectionsRenderer();
                          const map4 = new google.maps.Map(document.getElementById("directionsPanel"), {
                            zoom: 7,
                            center: { lat: 51.5074, lng: -0.1278 },
                          });
                        
                          directionsRenderer.setMap(map4);
						  // get the travelmode, startpoint and via point from the form   
						  var travelMode = $('input[name="travelMode"]:checked').val();
						  var start = $("#routeStart").val();
						  var via = $("#routeVia").val();
						  
						  if (travelMode == 'TRANSIT') {
						    via = ''; // if the travel mode is transit, don't use the via waypoint because that will not work
						  }
						 
						  var end = "<?php echo $list_loc_drive['coordinates']; ?>";
						  var waypoints = []; // init an empty waypoints array
						  if (via != '') {
						    // if waypoints (via) are set, add them to the waypoints array
						    waypoints.push({
						      location: via,
						      stopover: true
						    });
						  }
						  
						  var request = {
                            origin: start,
                            destination: end,
                            waypoints: waypoints,
                            unitSystem: google.maps.UnitSystem.IMPERIAL,
                            travelMode: google.maps.TravelMode[travelMode]
                        };
                    
                        directionsService.route(request)
                            .then((response) => {
                                directionsDisplay.setDirections(response);
                            })
                            .catch((e) => {
                                console.error("Directions request failed due to", e);
                                alert("Directions request failed due to " + e.message);
                            });
						}
					window.initMap = initMap;
						//google.maps.event.addDomListener(window, 'load', initialize);
					</script>

					 <div id="map_canvas"></div>    
					 
					 	<form action="" onSubmit="calcRoute();return false;" id="routeForm">

					 		<label><?php _e('From','atlas');?></label>
					 		<input type="text" id="routeStart" value="">

					 		<label><?php _e('Via (optional)','atlas');?></label>
					 		<input type="text" id="routeVia" value="">
					    
					     	
					     	<div class="label-float">
						        <label><?php _e('Travel Mode','atlas');?></label>
						        <label><input type="radio" name="travelMode" value="DRIVING" checked /> <?php _e('Driving','atlas');?></label>
						        <label><input type="radio" name="travelMode" value="BICYCLING" /> <?php _e('Bicycling','atlas');?></label>
						        <label><input type="radio" name="travelMode" value="TRANSIT" /> <?php _e('Public Transport','atlas');?></label>
						        <label><input type="radio" name="travelMode" value="WALKING" /> <?php _e('Walking','atlas');?></label>
					    	</div>

					        <div class="clear"></div>

					    	<input type="submit" value="<?php _e('Get Directions','atlas');?>">

					  </form>

					  <div id="directionsPanel" style="max-height: 1px; visibility: hidden; "></div>
			</div>