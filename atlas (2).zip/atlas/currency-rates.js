
// Set path to the iframe file
var filePath='http://accesstolondon.co.uk/wp-content/themes/atlas/currency-rates/';
var iframe='<iframe id="currency" name="currency-rates" src ="#" width="100%" height="1" marginheight="0" marginwidth="0" frameborder="no" scrolling="auto"></iframe>';
document.write(iframe);

var aspectRatio = .75;  //Middle value to accomodate height with 3 to 4 multiple delays

var myIframe = parent.document.getElementById("currency");
var iframeWidth = myIframe.clientWidth - 2;
myIframe.height = iframeWidth * aspectRatio;
myIframe.width = iframeWidth;

myIframe.src = filePath;
