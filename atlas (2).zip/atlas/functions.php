<?php



/**



 * functions and definitions



 *



 * @package Atlas



 */






define('TDP_FRAMEWORK_DIRECTORY', get_template_directory_uri() . '/framework/');



define('TDP_FRAMEWORK_VERSION', '2.3.0');





//define( 'ACF_LITE', true );







/**



 * Required: check for required plugins.



 */



require_once('framework/functions/class-tgm-plugin-activation.php' );

require_once get_template_directory() . '/export_custom_posts.php';
require_once get_template_directory() . '/custom-seo-listings.php';
require_once get_template_directory() . '/import-hotels.php';





/**



 * Required: include Custom Fields Framework.



 */
 //map api
function enqueue_google_maps() {
    // Enqueue script for the admin area
    if (is_admin()) {
        wp_enqueue_script(
            'google-maps-api-admin',
            'https://maps.googleapis.com/maps/api/js?key=AIzaSyDhNUHOm6M77yjTa_VvlXCulleuoPWZpLs', // Replace with your actual API key
            array(),
            null,
            true
        );
    } else {
        // Enqueue script for the front-end
        wp_enqueue_script(
            'google-maps-api-front',
            'https://maps.googleapis.com/maps/api/js?key=AIzaSyDhNUHOm6M77yjTa_VvlXCulleuoPWZpLs', // Replace with your actual API key
            array(),
            null,
            true
        );
    }
}
add_action('wp_enqueue_scripts', 'enqueue_google_maps', 20);
add_action('admin_enqueue_scripts', 'enqueue_google_maps');

add_action('wp_enqueue_scripts', 'enqueue_google_maps');
add_action('admin_enqueue_scripts', 'enqueue_google_maps');


function echo_custom_meta_description() {
    if (is_single()) { // Adjust for your custom post type
        global $post;

        $location = get_post_meta($post->ID, 'listings_location', true); // Replace with your actual location meta key
        $location_parts = explode('|', $location);
        $location = $location_parts[0] ?? ''; // Get the part before the pipe with null coalescing
        $category = get_the_terms($post->ID, 'listings_categories'); // Adjust taxonomy slug if necessary

        if ($category && !is_wp_error($category) && !empty($category)) {
            $category_name = $category[0]->name; // Get the first (and only) category
            $title = get_the_title($post->ID);
            
            $meta_description = "Explore $title located in $location, $category_name in London.";
            echo '<meta name="description" content="' . esc_attr($meta_description) . '">';
        } else {
            echo '';
        }
    }
}
add_action('wp_head', 'echo_custom_meta_description', 0);





function add_facebook_sdk() {
    ?>
    <div id="fb-root"></div>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v20.0" nonce="dAisXr6H"></script>
    <?php
}
add_action('wp_head', 'add_facebook_sdk');
function fb_page_plugin_shortcode() {
    ob_start();
    ?>
    <div class="fb-page" 
         data-href="https://www.facebook.com/Access.To.London/" 
         data-tabs="timeline" 
         data-width="350" 
         data-height="1000" 
         data-small-header="false" 
         data-adapt-container-width="true" 
         data-hide-cover="false" 
         data-show-facepile="true">
        <blockquote cite="https://www.facebook.com/Access.To.London/" class="fb-xfbml-parse-ignore">
            <a href="https://www.facebook.com/Access.To.London/">Access To London</a>
        </blockquote>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('fb_page_plugin', 'fb_page_plugin_shortcode');


require_once('framework/custom-fields/acf.php' );



require_once('framework/metaboxes/acf-flexible-content/acf-flexible-content.php' );



require_once('framework/metaboxes/acf-gallery/acf-gallery.php' );



require_once('framework/metaboxes/acf-repeater/acf-repeater.php' );



require_once('framework/metaboxes/acf-location-field-master/acf-location.php' );







/**



 * Required: include Main Options.



 */



require_once('framework/admin/acf-options-page/acf-options-page.php' );







// load more pages



if(function_exists("register_options_page"))



{



    register_options_page('Theme Options');



    register_options_page('Listings Settings');



    register_options_page('User Dashboard');



    register_options_page('Emails Setup');



    register_options_page('Fields Restrictions');



    register_options_page('Search Form Fields');



    register_options_page('Skin Customization');



}







if( function_exists('acf_set_options_page_title') )



{



    acf_set_options_page_title( __('Theme Options') );



}







/**



 * Required: include framework and theme functions.



 */



require_once('framework/fields/theme_options.php' );



//locate_template('/framework/fields/listings_post.php' );







add_action('init', 'load_exported_fields');



function load_exported_fields(){



    require_once( trailingslashit( get_stylesheet_directory() ) . 'framework/fields/listings_post.php' );



}







require_once('framework/fields/page_fields.php' );







require_once('framework/functions/required_plugins.php' );



require_once('framework/functions/core-functions.php' );



require_once('framework/functions/theme-functions.php' );



require_once('framework/functions/theme-setup.php' );



require_once('framework/functions/pmpro-integration.php' );



require_once('framework/functions/theme-customizer.php' );



if(!class_exists('Aq_Resize')) {



    require_once('framework/functions/aq_resizer.php' );



}



require_once('framework/functions/i18n.php' ); 







/**



 * Theme Extra Module



 */



require_once('framework/functions/listings/theme-specific.php' );



require_once('framework/functions/frontend_dashboard.php');



require_once('framework/functions/wpas.php');



require_once('framework/functions/listings/favorite/wp-favorite-posts.php');



if(get_field('enable_ajax_map','option')) {



    require_once('framework/functions/listings/ajax-loader.php');



}



new EFE_Frontend_Dashboard();


if(get_field('enable_listings_expire','option')):



    require_once('framework/functions/listings/listings-expire.php' );



endif;
 







/**



 * Add theme components from hangar plugin



 */







//Load additional modules



add_theme_support( 'tdp_cpt' );



add_theme_support( 'tdp_cpt_listings' );



add_theme_support( 'tdp_cpt_claim' );







//Add theme widgets



add_theme_support( 'tdp_widget_subscribe' );



add_theme_support( 'tdp_widget_l_details' );



add_theme_support( 'tdp_widget_l_contact' );



add_theme_support( 'tdp_widget_l_map' );



add_theme_support( 'tdp_widget_l_categories' );



add_theme_support( 'tdp_widget_l_locations' );



add_theme_support( 'tdp_widget_l_featured_author' );



add_theme_support( 'tdp_widget_l_listings' );



add_theme_support( 'tdp_widget_l_featured' );



add_theme_support( 'tdp_widget_l_search' );



add_theme_support( 'tdp_widget_l_profile' );







//Add shortcode support



add_theme_support( 'hangar_accordion' );



add_theme_support( 'hangar_alert' );



add_theme_support( 'hangar_button' );



add_theme_support( 'hangar_divider' );



add_theme_support( 'hangar_video' );



add_theme_support( 'hangar_maps' );



add_theme_support( 'hangar_gap' );



add_theme_support( 'hangar_clear' );



add_theme_support( 'hangar_icon' );



add_theme_support( 'hangar_miniicon' );



add_theme_support( 'hangar_retinaicon' );



add_theme_support( 'hangar_retinaiconbox' );



add_theme_support( 'hangar_list' );



add_theme_support( 'hangar_member' );



add_theme_support( 'hangar_skill' );



add_theme_support( 'hangar_pricing' );



add_theme_support( 'hangar_pullquote' );



add_theme_support( 'hangar_table' );



add_theme_support( 'hangar_tabs' );



add_theme_support( 'hangar_toggle' );



add_theme_support( 'hangar_sep' );



add_theme_support( 'hangar_googlefont' );



add_theme_support( 'hangar_columns' );



add_theme_support( 'hangar_teaser' );



add_theme_support( 'hangar_testimonial' );







/*



function acf_translate_fields( $field )



{



	$field['label' ] = __( $field['label' ], 'atlas'  );



	$field['instructions' ] = __( $field['instructions' ], 'atlas'  );







	return $field;



}



add_filter('acf/load_field' , 'acf_translate_fields' );



*/







add_action( 'after_setup_theme', 'dp_lang_setup' );



function dp_lang_setup() {



    load_theme_textdomain('atlas', get_template_directory()); 



}







// Register your custom function to override some LayerSlider data



add_action('layerslider_ready', 'my_layerslider_overrides');



 



function my_layerslider_overrides() {



 



// Disable auto-updates



$GLOBALS['lsAutoUpdateBox'] = false;







}







function tdp_fix_editor( $value, $post_id, $field )



{



    // run the_content filter on all textarea values



    $value = apply_filters('the_content',$value); 



 



    return $value;



}



 



// acf/load_value - filter for every value load



add_filter('acf/load_value/key=field_51e1444d75d73', 'tdp_fix_editor', 10, 3);







if ( ! function_exists( 'post_is_in_descendant_category' ) ) {



    function post_is_in_descendant_category( $cats, $_post = null ) {



        foreach ( (array) $cats as $cat ) {



            // get_term_children() accepts integer ID only



            $descendants = get_term_children( (int) $cat, 'listings_categories' );



            if ( $descendants && in_category( $descendants, $_post ) )



                return true;



        }



        return false;



    }



}



function image_alt_tags($content) {
    global $post;
    preg_match_all('/<img (.*?)\/>/', $content, $images);

    if (!is_null($images) && !empty($images[1])) {
        foreach ($images[1] as $index => $value) {
            if (!preg_match('/alt=/', $value)) {
                $new_img = str_replace('<img', '<img alt="' . esc_attr(get_the_title()) . '"', $images[0][$index]);
                $content = str_replace($images[0][$index], $new_img, $content);
            }
        }
    }

    return $content;
}

add_filter('the_content', 'image_alt_tags', 99999);





add_filter( 'xmlrpc_methods', 'C99_Remove_Pingback_Method' );



function C99_Remove_Pingback_Method( $methods ) {

   unset( $methods['pingback.ping'] );

   unset( $methods['pingback.extensions.getPingbacks'] );

   return $methods;

}




@ini_set( 'upload_max_size' , '10M' );

@ini_set( 'post_max_size', '10M');

@ini_set( 'max_execution_time', '3100' );

