<?php
// Ensure this runs within the WordPress environment
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
   
}
 
// Function to update description and keyphrases for Listings, Posts, and Pages
function update_keyphrases() {
    global $wpdb;

    // Access the aioseo_posts table
    $aioseo_table = $wpdb->prefix . 'aioseo_posts';
    $posts_table = $wpdb->prefix . 'posts';

    // Get all listing, post, and page post IDs and their titles
    $posts = $wpdb->get_results( "
        SELECT ID, post_title, post_type 
        FROM $posts_table 
        WHERE (post_type = 'listing' OR post_type = 'post' OR post_type = 'page') 
        AND post_status = 'publish'
    " );

    // Loop through each post
    foreach ( $posts as $post ) {
        $post_id = $post->ID;
        $post_title = $post->post_title;

        // Fetch existing keyphrases from the database
        $existing_keyphrases = $wpdb->get_var($wpdb->prepare("
            SELECT keyphrases FROM $aioseo_table WHERE post_id = %d
        ", $post_id));

        // Decode existing keyphrases
        $keyphrases_data = json_decode($existing_keyphrases, true);
        $additional_keyphrases = isset($keyphrases_data['additional']) ? $keyphrases_data['additional'] : array();

        // Initialize description
        $description = "Explore $post_title, your guide to listings in London.";

        // Check if the post is the homepage
        if ($post_title == "-Home--") {
            $description = "Your ultimate access to London guide: Discover the city's hidden gems, vibrant neighborhoods, and must-see attractions.";
            $keyphrases = json_encode(array(
                "focus" => array(
                    "keyphrase" => "Access to London",
                    "score" => "",
                    "analysis" => array(
                        // Your existing analysis logic...
                    )
                ),
                "additional" => $additional_keyphrases // Preserve any existing additional keyphrases
            ));
        } else {
            // For posts and pages, set focus keyphrase and description only
            $keyphrases = json_encode(array(
                "focus" => array(
                    "keyphrase" => $post_title,
                    "score" => "",
                    "analysis" => array(
                        // Your existing analysis logic...
                    )
                ),
                "additional" => $additional_keyphrases // Preserve any existing additional keyphrases
            ));
        }

        // Update the post in the aioseo_posts database
        $wpdb->update(
            $aioseo_table,
            array(
                'description' => $description,
                'keyphrases' => $keyphrases
            ),
            array('post_id' => $post_id),
            array(
                '%s', // description
                '%s'  // keyphrases (as JSON)
            ),
            array('%d') // post_id
        );
    }
}

// Hook the function to run on a specific action
add_action('init', 'update_keyphrases');
     
     
