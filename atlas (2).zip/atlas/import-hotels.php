<?php
// Add a menu item for the import page
function add_import_menu_item() {
    add_menu_page(
        'Import Data',   // Page title
        'Import Data',   // Menu title
        'manage_options', // Capability
        'import-custom-post-types', // Menu slug
        'import_custom_post_types_page' // Callback function
    );
}
add_action('admin_menu', 'add_import_menu_item');

// Display the import page with a dropdown for post types
function import_custom_post_types_page() {
    // Add nonce for security
    $nonce = wp_create_nonce('import_custom_post_type_nonce');
    
    // Get all registered post types
    $post_types = get_post_types(array('public' => true), 'objects');
    
    ?>
    <div class="wrap">
        <h1>Import Custom Post Types</h1>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <?php wp_nonce_field('import_custom_post_type_nonce'); ?>
            <input type="hidden" name="action" value="import_custom_post_type">
            <p>Select Post Type to Import:</p>
            <select name="post_type">
                <?php foreach ($post_types as $post_type) : ?>
                    <?php if ($post_type->name !== 'attachment') : // Exclude built-in 'attachment' post type ?>
                        <option value="<?php echo esc_attr($post_type->name); ?>">
                            <?php echo esc_html($post_type->label); ?>
                        </option>
                    <?php endif; ?>
                <?php endforeach; ?>
            </select>
            <input type="submit" class="button button-primary" value="Import Posts">
        </form>
        <?php
        // Display success or error message if any
        if (isset($_GET['import']) && $_GET['import'] === 'success') {
            echo '<div class="updated notice is-dismissible"><p>Import completed successfully.</p></div>';
        } elseif (isset($_GET['import']) && $_GET['import'] === 'error') {
            echo '<div class="error notice is-dismissible"><p>There was an error during import.</p></div>';
        }
        ?>
    </div>
    <?php
}

// Handle form submission to import selected post type
function handle_import_request() {
    if (isset($_POST['action'])) {
        // Import custom post type
        if ($_POST['action'] === 'import_custom_post_type') {
            // Verify nonce for security
            if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'import_custom_post_type_nonce')) {
                wp_die('Security check failed.');
            }

            $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';

            // Trigger the import process for the selected post type
            $registered_post_types = get_post_types(array('public' => true), 'names');
            if (in_array($post_type, $registered_post_types)) {
                import_custom_post_type_from_json($post_type);
            } else {
                wp_die('Invalid post type.');
            }
        }
    }
}
add_action('admin_post_import_custom_post_type', 'handle_import_request');

// Import custom post type from JSON file
function import_custom_post_type_from_json($post_type) {
    // Define the JSON file naming convention
    $json_file_name = $post_type . '.json';
    $json_file_path = get_stylesheet_directory() . '/data-to-import/' . $json_file_name;

    // Check if the JSON file exists
    if (!file_exists($json_file_path)) {
        wp_die('JSON file not found.');
    }

    // Get the contents of the file
    $json_contents = file_get_contents($json_file_path);

    // Decode the JSON data
    $data = json_decode($json_contents, true);

    // Check if the JSON data is valid
    if (!isset($data['Posts']) || !is_array($data['Posts'])) {
        wp_die('Invalid JSON data.');
    }

    // Start date for the first post
    $publish_date = new DateTime('tomorrow 08:00'); // Start publishing at 8:00 AM tomorrow
    
    foreach ($data['Posts'] as $post_data) {
        // Prepare post data
        $post_args = array(
            'post_title'     => wp_strip_all_tags($post_data['Title']),
            'post_content'   => $post_data['Content'],
            'post_status'    => 'future', // Schedule for future publication
            'comment_status' => $post_data['comment_status'],
            'post_type'      => $post_type,
            'post_date'      => $publish_date->format('Y-m-d H:i:s') // Schedule date
        );
    
        // Insert the post
        $post_id = wp_insert_post($post_args);
    
        // Add or update custom fields (meta data)
        if (isset($post_data['Meta']) && is_array($post_data['Meta'])) {
            foreach ($post_data['Meta'] as $key => $values) {
                if (is_array($values)) {
                    update_post_meta($post_id, $key, $values[0]);
                } else {
                    update_post_meta($post_id, $key, $values);
                }
            }
        }
    
        // Assign or update taxonomies
        if (isset($post_data['Taxonomies']) && is_array($post_data['Taxonomies'])) {
            foreach ($post_data['Taxonomies'] as $taxonomy => $terms) {
                $term_ids = wp_list_pluck($terms, 'ID');
                wp_set_post_terms($post_id, $term_ids, $taxonomy, false); // False to replace terms, true to append
            }
        }
    
        // Handle gallery images (example: __gallery meta key)
        if (isset($post_data['Meta']['__gallery']) && is_array($post_data['Meta']['__gallery'])) {
            $gallery_ids = array_map('intval', $post_data['Meta']['__gallery']);
            set_post_thumbnail($post_id, $post_data['Meta']['_thumbnail_id']); // Set thumbnail
            update_post_meta($post_id, '_gallery', $gallery_ids); // Add gallery images
        }
    
        // Automatically trigger post update
        wp_update_post(array('ID' => $post_id));
    
        // Increment publish date by 1 day for the next post
        $publish_date->modify('+1 day');
    }
    
    // Set the option to indicate import is complete
    update_option($post_type . '_imported', true);

    // Redirect back to the import page with a success message
    wp_redirect(admin_url('admin.php?page=import-custom-post-types&import=success'));
    exit;
}
