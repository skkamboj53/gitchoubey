<?php
/**
 * Template Name: All Listings + Map
 *
 * @package Atlas
 */
get_header();

$layout_ini = get_field('taxonomy_layout','option');
$set_layout = str_replace(' ', '', $layout_ini);

// Set grid layout column size based on page layout

if(get_field('taxonomy_layout','option') !== 'Fullwidth') { 

	$grid_set_column = 'one_third';
	$row_num = 3;

} else {

	$grid_set_column = 'one_fourth';
	$row_num = 4;

}
?>

<section id="header-map" class="slidingDiv">

	<a href="#search-popup" id="open-search" <?php if(get_field('street_view_control','option')) { echo 'class="push2"'; } ?>><span class="icon-search"></span></a>

	<?php if(get_field('enable_ajax_map','option') && !wp_is_mobile() && get_field('enable_geolocation_on_click','option')) : ?>

	<a href="#" id="enable-geolocation" <?php if(get_field('street_view_control','option')) { echo 'class="push2"'; } ?> title="<?php _e('Enable Geolocation','atlas');?>"><span class="icon-location"></span></a>

	<?php endif; ?>

	<div id="map"></div>

	<?php 

		//check if ajax map is enabled otherwise load normal map system

		if(get_field('enable_ajax_map','option')) {

			do_action('tdp_after_taxonomy_map');

		} else {

			get_template_part( 'includes/map', 'loader' );

		}

	?>

</section>

<div class="clear"></div>

<?php if(get_field('display_categories_filter','option') && get_field('enable_ajax_map','option')) : ?>

<div id="front-categories-filter">
	<?php 
	$terms = get_terms("listings_categories",'hide_empty=1&parent=0&number=10');
	$count = count($terms);
	if ( $count > 0 ){
		echo '<div class="single-cat-filter wrapper" rel="0">';
		foreach ( $terms as $term ) { ?>  
		
		<div class="cat-title"><a href="#" onclick="displayMarkers('<?php echo $term->slug;?>');"><img src="<?php echo get_field('marker_type', 'listings_categories_' . $term->term_id ); ?>"/></a></div>

		<?php }
		echo "</div>";
	}
	?>
</div>

<?php endif; ?>

<section id="page-wrapper">

	<div id="page-content" class="wrapper">

		<?php if(get_field('taxonomy_layout','option') == 'Sidebar Left') { ?>

			<div class="one_fourth" id="sidebar-wrapper">
				<?php dynamic_sidebar( 'Listings Sidebar' ); ?>
			</div>

		<?php } ?>

		<div id="content-container" class="<?php if(get_field('taxonomy_layout','option') == 'Sidebar Left') { echo 'three_fourth last'; } else if(get_field('taxonomy_layout','option') == 'Sidebar Right') { echo 'three_fourth'; } ?>">

			<?php
			if ( get_query_var('paged') ) {
			    $paged = get_query_var('paged');
			} elseif ( get_query_var('page') ) {
			    $paged = get_query_var('page');
			} else {
			    $paged = 1;
			}

			query_posts( array( 'post_type' => 'listing', 'posts_per_page' => get_field('listings_per_page','option'), 'paged' => $paged ) );

			$clear_row = '';
			$clear_row_end = '';

			if ( have_posts() ) : ?>

				<?php while ( have_posts() ) : the_post(); //Lets check if the user has selected a different layout

							//display list view
							if (isset($_GET['listview']) && $_GET['listview'] == "list") {
    							
    							get_template_part( 'content', 'listing-list-view' );
							
							//Display grid view
							} else if (isset($_GET['listview']) && $_GET['listview'] == "grid") { ?>

							<div class="grid-column <?php echo $grid_set_column; ?> <?php if($clear_row == $row_num ) { echo " last"; $clear_row = 0; } ?>">
							<?php get_template_part( 'content', 'listing-list-grid' ); ?>
							</div>

							<?php if($clear_row_end == $row_num) { echo '<div class="clear"></div>'; $clear_row_end = 0; } ?>

							<?php } else {

								get_template_part( 'content', 'listing-list-view' );

							}

						endwhile; ?>

					<?php 

					wp_pagenavi();
					wp_reset_postdata(); 

					?>

			<?php else : ?>

				<?php get_template_part( 'no-results', 'index' ); ?>

			<?php endif; ?>

		</div>

		<?php if(get_field('taxonomy_layout','option') == 'Sidebar Right'  ) { ?>

			<div class="one_fourth last" id="sidebar-wrapper">
				<?php dynamic_sidebar( 'Listings Sidebar' ); ?>
			</div>

		<?php } ?>

		<div class="clearboth"></div>

	</div>

</section>

<?php get_template_part( 'includes/search', 'listings' );?>

<?php get_footer(); ?>