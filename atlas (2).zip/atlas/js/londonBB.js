
// Set path to the iframe file
var filePath='http://accesstolondon.co.uk/londonBB.php';
var iframe='<iframe id="londonBB" name="BB" src ="#" width="100%" height="1" marginheight="0" marginwidth="0" frameborder="no" scrolling="auto"></iframe>';
document.write(iframe);

var aspectRatio = 0.88;  //Middle value to accomodate height with 3 to 4 multiple delays

var myIframe = parent.document.getElementById("londonBB");
var iframeWidth = myIframe.clientWidth - 2;
myIframe.height = iframeWidth * aspectRatio;
myIframe.width = iframeWidth;

myIframe.src = filePath;
