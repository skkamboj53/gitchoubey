<?php

/*

* Template Name: Homepage With Map And Custom Content


 */



get_header();



$sidebar_position = get_field('inner_page_layout');



?>



<section id="header-map" class="slidingDiv">



	<a href="#search-popup" id="open-search" <?php if(get_field('street_view_control','option')) { echo 'class="push2"'; } ?>><span class="icon-search"></span></a>



	<?php if(get_field('enable_ajax_map','option') && !wp_is_mobile() && get_field('enable_geolocation_on_click','option')) : ?>



	<a href="#" id="enable-geolocation" <?php if(get_field('street_view_control','option')) { echo 'class="push2"'; } ?> title="<?php _e('Enable Geolocation','atlas');?>"><span class="icon-location"></span></a>



	<?php endif; ?>



	<div id="map"></div>



	<?php 



		//check if ajax map is enabled otherwise load normal map system



		if(get_field('enable_ajax_map','option')) {



			do_action('tdp_after_taxonomy_map');



		} else {



			get_template_part( 'includes/map', 'loader' );



		}



	?>



</section>



<div class="clear"></div>



<?php if(get_field('display_categories_filter','option')) : ?>



<div id="front-categories-filter">

	<?php 

	$terms = get_terms("listings_categories",'hide_empty=1&parent=0&number=10');

	$count = count($terms);

	if ( $count > 0 ){

		echo '<div class="single-cat-filter wrapper" rel="0">';

		foreach ( $terms as $term ) { ?>  

		

		<div class="cat-title"><a href="#" onclick="displayMarkers('<?php echo $term->slug;?>');"><img src="<?php echo get_field('marker_type', 'listings_categories_' . $term->term_id ); ?>"/></a></div>



		<?php }

		echo "</div>";

	}

	?>

</div>



<?php endif; ?>



<section id="page-wrapper">



	<div id="page-content" class="wrapper">



		<?php if($sidebar_position == 'Sidebar Left') { ?>



			<div class="one_third" id="sidebar-wrapper">

				<?php dynamic_sidebar( 'Page Sidebar' ); ?>

			</div>



		<?php } ?>





		<div id="content-container" class="<?php if($sidebar_position == 'Sidebar Left') { echo 'two_third last'; } else if($sidebar_position == 'Sidebar Right') { echo 'two_third'; } ?>">



			<?php if ( have_posts() ) : ?>



				<?php while ( have_posts() ) : the_post(); ?>



					<article <?php post_class();?>>



						<?php get_template_part( 'content', 'page' ); ?>



					</article>



				<?php endwhile; ?>



			<?php else : ?>



				<?php get_template_part( 'no-results', 'index' ); ?>



			<?php endif; ?>



		</div>



		<?php if($sidebar_position == 'Sidebar Right'  ) { ?>



			<div class="one_third last" id="sidebar-wrapper">

				<?php dynamic_sidebar( 'Page Sidebar' ); ?>

			</div>



		<?php } ?>



		<div class="clearboth"></div>



	</div>



</section>



<?php get_template_part( 'includes/search', 'listings' );?>

<?php get_footer();?>