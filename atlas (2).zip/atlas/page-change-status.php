<?php
/**
 * Template Name: Publish Old Drafts
 */

if ( ! current_user_can( 'administrator' ) ) {
    wp_die( 'You do not have sufficient permissions to access this page.' );
}

function publish_old_draft_posts() {
    global $wpdb;

    // Define the date before which the posts should be published
    $date = '2016-04-14';

    // Get all draft posts before the specified date
    $posts = $wpdb->get_results(
        $wpdb->prepare(
            "
            SELECT ID 
            FROM $wpdb->posts 
            WHERE post_status = 'draft' 
            AND post_date < %s
            ",
            $date
        )
    );

    if ( $posts ) {
        foreach ( $posts as $post ) {
            // Update the post status to publish
            wp_update_post( array(
                'ID' => $post->ID,
                'post_status' => 'publish',
            ));
        }
        echo "<p>All eligible draft posts have been published.</p>";
    } else {
        echo "<p>No draft posts found before the specified date.</p>";
    }
}

// Call the function
publish_old_draft_posts();
?>