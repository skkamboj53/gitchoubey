<?php
/**
 * WP_Atlas_Expire
 */
class WP_Atlas_Expire {

	/**
	 * __construct function.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {
		$this->cron();
	}

	/**
	 * Setup cron listings
	 */
	public function cron() {
		wp_clear_scheduled_hook( 'atlas_check_for_expired_listings' );
		wp_clear_scheduled_hook( 'atlas_delete_old_previews' );
		
		//wp_schedule_event( time(), 'daily', array( $this,'atlas_delete_old_previews' );
		add_action( 'pending_to_publish', array( $this, 'set_expirey' ) );
		add_action( 'preview_to_publish', array( $this, 'set_expirey' ) );
		add_action( 'draft_to_publish', array( $this, 'set_expirey' ) );
		add_action( 'auto-draft_to_publish', array( $this, 'set_expirey' ) );
		//add_action( 'expired_to_publish', array( $this, 'set_expirey' ) );
		add_action("tdp_after_change_membership_level", array( $this,"atlas_set_global_expire_date_by_membership"), 15, 99);
	}

	
	/**
	 * Set expirey date when job status changes
	 */
	public function set_expirey( $post ) {
		if ( $post->post_type !== 'listing' ) {
			return;
		}

		// See if it is already set
		$expires  = get_post_meta( $post->ID, '_listing_expires', true );

		if ( ! empty( $expires ) ) {
			return;
		}

		// Get duration from the product if set...
		// Grab duration from user meta
		$author_id=$post->post_author;

		$the_date = get_user_meta( $author_id,'listings_global_expire_date', 1 );
		$final_date = trim($the_date, "'");
		$from=date_create(date('Y-m-d'));
		$to=date_create($final_date);
		$diff=date_diff($to,$from);

		$duration = $diff->days;

		// ...otherwise use the global option
		if ( ! $duration )
			$duration = apply_filters('atlas_listings_days_expire', null);

		if ( $duration ) {
			$expires = date( 'Y-m-d', strtotime( "+{$duration} days", current_time( 'timestamp' ) ) );
			update_post_meta( $post->ID, '_listing_expires', $expires );

			// In case we are saving a post, ensure post data is updated so the field is not overridden
			if ( isset( $_POST[ '_listing_expires' ] ) )
				$_POST[ '_listing_expires' ] = $expires;

		} else {
			update_post_meta( $post->ID, '_listing_expires', '' );
		}
	}

	function atlas_set_global_expire_date_by_membership($level_id, $user_id) {	
			
		global $pmpro_levels, $current_user;
		//get user info
		$list_user = get_userdata($user_id);

		////calculate the end date
		$the_level_being_purchased = $pmpro_levels[$level_id];
		$listings_global_expire_date = "'" . date("Y-m-d", strtotime("+ " . $the_level_being_purchased->expiration_number . " " . $the_level_being_purchased->expiration_period)) . "'";

		update_user_meta( $user_id, 'listings_global_expire_date', $listings_global_expire_date );

  		//print "<pre>";
  		//print_r($listings_global_expire_date);	
  		//print "</pre>";
	}

}

new WP_Atlas_Expire();

/**
 * Expire listings
 */
	function atlas_check_for_expired_listings() {
		global $wpdb;

		// Change status to expired
		$listing_ids = $wpdb->get_col( $wpdb->prepare( "
			SELECT postmeta.post_id FROM {$wpdb->postmeta} as postmeta
			LEFT JOIN {$wpdb->posts} as posts ON postmeta.post_id = posts.ID
			WHERE postmeta.meta_key = '_listing_expires'
			AND postmeta.meta_value > 0
			AND postmeta.meta_value < %s
			AND posts.post_status = 'publish'
			AND posts.post_type = 'listing'
		", date( 'Y-m-d', current_time( 'timestamp' ) ) ) );

		if ( $listing_ids ) {
			foreach ( $listing_ids as $listing_id ) {
				$listing_data       = array();
				$listing_data['ID'] = $listing_id;
				$listing_data['post_status'] = 'draft';
				wp_update_post( $listing_data );
			}
		}

		// Delete old expired listings
		$listing_ids = $wpdb->get_col( $wpdb->prepare( "
			SELECT posts.ID FROM {$wpdb->posts} as posts
			WHERE posts.post_type = 'listing'
			AND posts.post_modified < %s
			AND posts.post_status = 'draft'
		", date( 'Y-m-d', strtotime( '-30 days', current_time( 'timestamp' ) ) ) ) );

		if ( $listing_ids ) {
			foreach ( $listing_ids as $listing_id ) {
				wp_trash_post( $listing_id );
			}
		}
	}
wp_schedule_event( time(), 'hourly', 'atlas_check_for_expired_listings' );