<?php 
/**
 * Adds Listings Amount Field.
 * @package Atlas
 */
function pmpro_add_settings_to_membership() {
	$level_id = intval($_REQUEST['edit']);
	if($level_id > 0)
		$level_allowance = pmpro_get_membership_allowance($level_id);	
	else
		$level_allowance = "";
?>
<h3 class="topborder"><?php _e('Listings Allowance', 'atlas');?></h3>
<p><?php _e('Enter the amount of listings users can submit through this membership.', 'atlas'); ?></p>
<table>
<tbody class="form-table">
	<tr>
		<td>
			<tr>
				<th scope="row" valign="top"><label for="pmpro_membership_allowance"><?php _e('Allowance', 'atlas');?></label></th>
				<td>
					<input name="pmpro_membership_allowance" type="text" size="20" value="<?php echo $level_allowance; ?>">
				</td>
			</tr>
		</td>
	</tr> 
</tbody>
</table>
<?php }
add_action("pmpro_membership_level_after_other_settings", "pmpro_add_settings_to_membership");

/**
 * Saves the membership setting
 * @package Atlas
 */
function pmpro_save_membership_setting($level_id)
{
    pmpro_save_set_allowance($level_id, $_REQUEST['pmpro_membership_allowance']);
}
add_action("pmpro_save_membership_level", "pmpro_save_membership_setting");

/**
 * Saves the membership setting
 * @package Atlas
 */
function pmpro_save_set_allowance($level_id, $set_membership_allowance, $code_id = NULL)
{
    if($code_id)
        $key = "pmprosed_" . $level_id . "_" . $code_id;
    else
        $key = "pmprosed_" . $level_id;

    update_option($key, $set_membership_allowance);
}

/**
 * Saves the membership setting
 * @package Atlas
 */
function pmpro_get_membership_allowance($level_id, $code_id = NULL)
{
    if($code_id)
        $key = "pmprosed_" . $level_id . "_" . $code_id;
    else
        $key = "pmprosed_" . $level_id;

    return get_option($key, "");
}

/**
 * Saves the membership allowance into metafield on membership change
 * @package Atlas
 */
function pmpro_save_allowance_after_membership_change($user_id = NULL) {

	global $pmpro_levels, $current_user;

	$user_id = $current_user->ID;

	$level_allowance = pmpro_get_membership_allowance($_GET['level']);

	update_user_meta( $user_id, 'pmpro_allowance_limit', $level_allowance );

}
add_action('pmpro_after_checkout','pmpro_save_allowance_after_membership_change', 99);